# Online Code Editor 
Deployment: https://online-code-editor-react.vercel.app/

## Libraries used: codemirror & react-codemirror2
## Created Online code editor that resides on a remote server and is accessible via browsers. This online code editor have basic features like syntax highlighting.
##
![i1](https://user-images.githubusercontent.com/62508572/126872072-20d10874-f145-4501-9815-5b501601535e.png)



## Local Setup
1. Run "npm install" to install required dependencies
2. Run "npm start" to start the app on local server on port 3000
